from arbitrium.menu import menu, requires_auth
